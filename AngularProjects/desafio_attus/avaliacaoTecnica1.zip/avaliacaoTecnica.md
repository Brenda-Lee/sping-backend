# Avaliação Técnica

---

## 1. TypeScript e Qualidade de Código

### 1.1 Refatoração

> Considerando seus conhecimentos de TypeScript, qualidade de código e boas práticas, quais melhorias você faria no seguinte código:
>
> ```typescript
> class Produto {
>   id: any;
>   descricao: any;
>   quantidadeEstoque: any;
>
>   constructor(id: any, descricao: any, quantidadeEstoque: any) {
>     this.id = id;
>     this.descricao = descricao;
>     this.quantidadeEstoque = quantidadeEstoque;
>   }
> }
>
> class Verdureira {
>   produtos: any;
>
>   constructor() {
>     this.produtos = [
>       new Produto(1, 'Maçã', 20),
>       new Produto(2, 'Laranja', 0),
>       new Produto(3, 'Limão', 20)
>     ];
>   }
>
>   getDescricaoProduto(produtoId: any) {
>     let produto;
>
>     for (let index = 0; index < this.produtos.length; index++) {
>       if (this.produtos[index].id == produtoId) {
>         produto = this.produtos[index];
>       }
>     }
>
>     return produto.id + ' - ' + produto.descricao + ' (' + produto.quantidadeEstoque + 'x)';
>   }
>
>   hasEstoqueProduto(produtoId: any) {
>     let produto;
>
>     for (let index = 0; index < this.produtos.length; index++) {
>       if (this.produtos[index].id == produtoId) {
>         produto = this.produtos[index];
>       }
>     }
>
>     if (produto.quantidadeEstoque > 0) {
>       return true;
>     } else {
>       return false;
>     }
>   }
> }
> ```

#### Resposta

```typescript
// Primeiro eliminei o uso de any (declaração de tipo assim inutiliza o propósito do typescript), depois simplifiquei o construtor da classe produto
// declarando e atribuindo as propriedades nele direto (evita repetições de código). O 'readonly' é uma proteção extra, para que o estoque não possa
// ser alterado diretamente. Passei a responsabilidade de saber se há produtos no estoque e de formatar a descrição para a classe produto propriamente,
// a classe Verdureira não carrega mais a lógica. Removi a duplicação de loop na classe Verdureira e também adicionei tratamento de erro.

class Produto {
 constructor(
  public readonly id: number,
  public readonly descricao: string,
  public readonly quantidadeEstoque: number) {
 }

 produtoEmEstoque(): boolean {
   return this.quantidadeEstoque > 0;
 }

 formatarDescricao(): string {
   return `${this.id} - ${this.descricao} (${this.quantidadeEstoque}x)`;
 }

}

class Verdureira {
  private produtos: Produto[] = [
    new Produto(1, 'Maçã', 20),
    new Produto(2, 'Laranja', 0),
    new Produto(3, 'Limão', 20)
  ];

  private getProdutoPorId(produtoId: number): Produto {
    const produto = this.produtos.find(p => p.id === produtoId);

    if (!produto) {
      throw new Error('Produto não encontrado');
    }
    
    return produto;
  }

  getDescricaoProduto(produtoId: number): string {
    return this.getProdutoPorId(produtoId).formatarDescricao();
  }

  hasEstoqueProduto(produtoId: number): boolean {
    return this.getProdutoPorId(produtoId).produtoEmEstoque();
  }
}
```

---

### 1.2 Generics e Tipos Utilitários

> Implemente uma função genérica `filtrarEPaginar<T>` que recebe um array, um predicado de filtro e parâmetros de paginação (página e tamanho). A função deve retornar os itens da página atual e o total de registros filtrados. Use tipagem completa — sem `any`.
>
> ```typescript
> filtrarEPaginar<T>(
>   data: T[],
>   filterFn: (item: T) => boolean,
>   params: PaginaParams
> ): Pagina<T>
> ```
>
> Demonstre o uso com um exemplo concreto (ex: array de usuários com filtro por nome).

#### Resposta

```typescript

interface PaginaParams {
  pagina: number;
  tamanho: number;
}

interface Pagina<T> {
  registros: T[];
  total: number;
  pagina: number;
  tamanho: number;
  totalPaginas: number;
}

function filtrarEPaginar<T>(
  data: T[],
  filterFn: (item: T) => boolean,
  params: PaginaParams
): Pagina<T> {
  const { pagina, tamanho } = params;

  const registrosFiltrados = data.filter(filterFn);

  const inicio = (pagina - 1) * tamanho;
  const fim = inicio + tamanho;

  const registrosPaginados = registrosFiltrados.slice(inicio, fim);

  return {
    registros: registrosPaginados,
    total: registrosFiltrados.length,
    pagina,
    tamanho,
    totalPaginas: Math.ceil(registrosFiltrados.length / tamanho)
  };
}

interface Usuario {
  id: number;
  nome: string;
  email: string;
}

const usuarios: Usuario[] = [
  { id: 1, nome: 'Ana', email: 'ana@email.com' },
  { id: 2, nome: 'Bruno', email: 'bruno@email.com' },
  { id: 3, nome: 'Carlos', email: 'carlos@email.com' },
  { id: 4, nome: 'Carla', email: 'carla@email.com' },
  { id: 5, nome: 'Daniel', email: 'daniel@email.com' }
];

const resultado = filtrarEPaginar(
  usuarios,
  (usuario) => usuario.nome.toLowerCase().includes('a'),
  {
    pagina: 1,
    tamanho: 2
  }
);

console.log(resultado);

```

---

## 2. Angular — Fundamentos e Reatividade

### 2.1 Change Detection e OnPush

> O componente abaixo usa `ChangeDetectionStrategy.OnPush`, mas o nome não é exibido na tela. Identifique o problema, explique o motivo e proponha a correção — sem alterar a estratégia, sem modificar `PessoaService` e sem remover o `setInterval`.
>
> ```typescript
> import { ChangeDetectionStrategy, Component, Injectable, OnInit, OnDestroy } from '@angular/core';
> import { of, Subscription } from 'rxjs';
> import { delay } from 'rxjs/operators';
>
> @Injectable()
> class PessoaService {
>   /** @description Mock de uma busca em API com retorno em 0.5 segundos */
>   buscarPorId(id: number) {
>     return of({ id, nome: 'João' }).pipe(delay(500));
>   }
> }
>
> @Component({
>   selector: 'app-root',
>   providers: [PessoaService],
>   changeDetection: ChangeDetectionStrategy.OnPush,
>   template: `<h1>{{ texto }}</h1>`,
> })
> export class AppComponent implements OnInit, OnDestroy {
>   texto: string;
>   contador = 0;
>   subscriptionBuscarPessoa: Subscription;
>   constructor(private readonly pessoaService: PessoaService) {}
>
>   ngOnInit(): void {
>     this.subscriptionBuscarPessoa = this.pessoaService.buscarPorId(1).subscribe((pessoa) => {
>       this.texto = `Nome: ${pessoa.nome}`;
>     });
>
>     setInterval(() => this.contador++, 1000);
>   }
>
>   ngOnDestroy(): void {
>     /** ... */
>   }
> }
> ```

#### Resposta

**Problema identificado:**

Angular não executa detecção de mudanças automaticamente para qualquer alteração interna do componente quando
se utiliza 'onPush'

**Motivo:**

**Correção:**

```typescript

 import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Injectable, OnInit, OnDestroy } from '@angular/core';
 import { of, Subscription } from 'rxjs';
 import { delay } from 'rxjs/operators';

 @Injectable()
 class PessoaService {
   /** @description Mock de uma busca em API com retorno em 0.5 segundos */
   buscarPorId(id: number) {
     return of({ id, nome: 'João' }).pipe(delay(500));
   }
 }

 @Component({
   selector: 'app-root',
   providers: [PessoaService],
   changeDetection: ChangeDetectionStrategy.OnPush,
   template: `<h1>{{ texto }}</h1>`,
 })
 export class AppComponent implements OnInit, OnDestroy {
   texto: string;
   contador = 0;
   subscriptionBuscarPessoa: Subscription;

   constructor(
    private readonly pessoaService: PessoaService,
    private readonly cdr: ChangeDetectorRef ) {}

   ngOnInit(): void {
     this.subscriptionBuscarPessoa = this.pessoaService.buscarPorId(1).subscribe((pessoa) => {
       this.texto = `Nome: ${pessoa.nome}`;
       this.cdr.markForCheck();
     });

     setInterval(() => this.contador++, 1000);
   }

   ngOnDestroy(): void {
     this.subscriptionBuscarPessoa?.unsubscribe();
   }
 }

```

---

### 2.2 RxJS — Eliminando Subscriptions Aninhadas

> Refatore o código abaixo eliminando o `subscribe` dentro de `subscribe`. Use operadores RxJS adequados, evite memory leaks e explique brevemente sua escolha de operador.
>
> ```typescript
> ngOnInit(): void {
>   const pessoaId = 1;
>
>   this.pessoaService.buscarPorId(pessoaId).subscribe(pessoa => {
>     this.pessoaService.buscarQuantidadeFamiliares(pessoaId).subscribe(qtd => {
>       this.texto = `Nome: ${pessoa.nome} | familiares: ${qtd}`;
>     });
>   });
> }
> ```

#### Resposta

**Operador escolhido e motivo:**

```typescript
// cole aqui o código refatorado
```

---

### 2.3 RxJS — Busca com Debounce

> Implemente um campo de busca reativo em um componente Angular que:
> - Aguarde 500 ms após o usuário parar de digitar antes de disparar a requisição (debounce)
> - Cancele a requisição anterior caso o usuário digite novamente (evite race condition)
> - Exiba um indicador de loading enquanto a requisição está em andamento
> - Gerencie a subscription sem memory leak
>
> Mostre o serviço, o componente e o template com `async pipe`.

#### Resposta

**Serviço:**

```typescript
// cole aqui o serviço
```

**Componente:**

```typescript
// cole aqui o componente
```

**Template:**

```html
<!-- cole aqui o template -->
```

---

### 2.4 Performance — OnPush e trackBy

> Considere uma lista com centenas de itens renderizados com `@for` (`ngFor`). Explique:
> - Por que usar `trackBy` melhora a performance e como implementá-lo corretamente
> - Como `ChangeDetectionStrategy.OnPush` pode reduzir ciclos desnecessários de detecção neste cenário
> - Qual seria o impacto de usar a estratégia `Default` neste caso

#### Resposta

**trackBy — por que melhora e como implementar:**

**OnPush — impacto na detecção de mudanças:**

**Estratégia Default — impacto:**

---

## 3. Gerenciamento de Estado

### 3.1 Angular Signals — Estado Local

> Crie um componente de contador de itens no carrinho usando exclusivamente Signals. O componente deve expor:
> - Um signal para a lista de itens
> - Um `computed` para o total (quantidade × preço)
> - Um método para adicionar e remover itens
> - Um `output()` que emite sempre que o total mudar

#### Resposta

```typescript
// cole aqui o componente com Signals
```

---

### 3.2 Gerenciamento de Estado com NgRx (Feature To-do)

> Implemente a estrutura de estado para uma lista de tarefas (To-do) utilizando os padrões recomendados do NgRx. A implementação deve incluir:
> - **Actions:** `loadTodos`, `loadTodosSuccess`, `loadTodosError` e `toggleTodoComplete`
> - **Reducer:** estado inicial e transição de estados com `createReducer`, com tipagem forte
> - **Selectors:** `selectAllTodos` (lista completa) e `selectPendingTodos` (tarefas não concluídas)
> - **Effect:** ao disparar `loadTodos`, realiza chamada HTTP (mockada) e despacha sucesso ou erro

#### Resposta

**Actions:**

```typescript
// cole aqui as actions
```

**Reducer:**

```typescript
// cole aqui o reducer
```

**Selectors:**

```typescript
// cole aqui os selectors
```

**Effect:**

```typescript
// cole aqui o effect
```
